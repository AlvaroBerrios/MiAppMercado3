package com.example.miappmercado;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class PrincipalMercado extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal_mercado);
    }
}
